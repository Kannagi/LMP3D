#!/bin/sh
/home/kannagi/Documents/SDK/PS2/ps2dev/ps2sdk/bin/bin2c DATA DATA_ROM.c DATA_ROM
