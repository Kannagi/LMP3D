#!/bin/bash
terminal -x bash compilation.sh
