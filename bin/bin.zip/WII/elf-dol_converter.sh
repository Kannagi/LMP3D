#!/bin/bash
/home/kannagi/devkitPro/devkitPPC/bin/elf2dol Wii_demo.elf boot.dol
