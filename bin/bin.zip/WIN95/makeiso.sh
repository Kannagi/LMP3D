#!/bin/bash
rm Demo.iso
mkisofs -iso-level 1  -o Demo.iso *



